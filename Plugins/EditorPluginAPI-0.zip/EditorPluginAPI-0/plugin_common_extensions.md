## "std"
> Зарезервировано в соответствии со стандартом

## "abel"
 - [@abel1502](https://github.com/abel1502)
 - Предоставляется только приложением.
 - Дополнительный функционал, доступный в редакторе [Abel Photoshoop](https://github.com/abel1502/mipt_3s/tree/master/VS/Photoshoop).
 - Появится в дальнейшем где-то [здесь](https://github.com/abel1502/mipt_3s/tree/master/VS/Photoshoop)


